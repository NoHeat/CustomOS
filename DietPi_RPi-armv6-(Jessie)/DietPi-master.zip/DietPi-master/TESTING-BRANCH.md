## Steps to use the DietPi "testing" branch.
#### Please note, this is the active development branch. Its potentially unstable, unsupported and should not be used by end users.

1. Write the DietPi image to SD card.
2. Open the file on the 1st partition ```/boot/dietpi.txt```
3. Change ```gitbranch=master``` to ```gitbranch=testing``` (located at the bottom of file)
4. Save the file, eject media and power on.